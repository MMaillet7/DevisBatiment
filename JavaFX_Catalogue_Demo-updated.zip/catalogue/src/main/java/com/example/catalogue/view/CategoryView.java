package com.example.catalogue.view;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.util.List;

/**
 * Classe de base pour les vues d'une categorie.
 * A gauche : demonstrations des composants (60% -> 33%).
 * A droite : plan 2D live (66%) + menu deroulant d'etage.
 */
public abstract class CategoryView {

    private final SplitPane root = new SplitPane();
    private final VBox      demos = new VBox(15);

    // Plan 2D panel
    private final Canvas    canvas     = new Canvas(500, 380);
    private final ComboBox<String> etageBox = new ComboBox<>();
    private int             etageActuel = 0;

    // Donnees du plan (modifiables depuis les sous-classes / controleurs)
    private List<String> etages = List.of("Niveau 0 – RDC");

    protected CategoryView() {
        construireSqueletteCommun();
        construireDemos(demos);
        dessinerPlan();
    }

    private void construireSqueletteCommun() {
        demos.setPadding(new Insets(15));
        ScrollPane scroll = new ScrollPane(demos);
        scroll.setFitToWidth(true);

        // --- Plan 2D panel ---
        Label titrePlan = new Label("Plan 2D – en direct");
        titrePlan.setStyle("-fx-font-weight:bold; -fx-font-size:13;");

        etageBox.setItems(FXCollections.observableArrayList(etages));
        etageBox.getSelectionModel().selectFirst();
        etageBox.setMaxWidth(Double.MAX_VALUE);
        etageBox.getSelectionModel().selectedIndexProperty().addListener((obs, o, n) -> {
            etageActuel = n.intValue();
            dessinerPlan();
        });

        ScrollPane scrollCanvas = new ScrollPane(canvas);
        scrollCanvas.setFitToWidth(true);
        scrollCanvas.setFitToHeight(true);
        VBox.setVgrow(scrollCanvas, Priority.ALWAYS);

        VBox panneauPlan = new VBox(8, titrePlan, scrollCanvas, etageBox);
        panneauPlan.setPadding(new Insets(15));
        VBox.setVgrow(panneauPlan, Priority.ALWAYS);

        root.getItems().addAll(scroll, panneauPlan);
        root.setDividerPositions(0.34);
    }

    // ------------------------------------------------------------------ //
    //  Plan 2D                                                             //
    // ------------------------------------------------------------------ //

    /** Redessine le plan selon l'etage courant. */
    public void dessinerPlan() {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        double W = canvas.getWidth(), H = canvas.getHeight();
        gc.clearRect(0, 0, W, H);

        gc.setFill(Color.web("#f0f4f8"));
        gc.fillRect(0, 0, W, H);

        if (etageActuel == 0) {
            dessinerRDC(gc);
        } else {
            dessinerEtageN(gc, etageActuel);
        }
    }

    private void dessinerRDC(GraphicsContext gc) {
        double ox = 20, oy = 24;
        titre(gc, "Plan 2D – Niveau 0 (RDC)  —  " + getNomBatiment(), ox, oy);

        piece(gc, ox+190, oy+30, 200, 90,  "#d6eaf8", "Chambre",      "12.0 m²", "#1a5276");
        piece(gc, ox+190, oy+120, 200, 100, "#d5f5e3", "Cuisine",       "9.0 m²",  "#1e8449");
        piece(gc, ox+16,  oy+120, 174, 100, "#fef9e7", "Salon",        "18.0 m²", "#7d6608");
        piece(gc, ox+16,  oy+30,  174, 90,  "#fadbd8", "Salle de bain","6.5 m²",  "#922b21");

        // porte
        gc.setStroke(Color.web("#f0f4f8")); gc.setLineWidth(3);
        gc.strokeLine(ox+190, oy+75, ox+190, oy+95);

        // fenetre
        gc.setStroke(Color.web("#2980b9")); gc.setLineWidth(2.5);
        gc.setLineDashes(6, 4);
        gc.strokeLine(ox+250, oy+30, ox+330, oy+30);
        gc.setLineDashes(0);

        legende(gc, ox, oy + 240);
    }

    private void dessinerEtageN(GraphicsContext gc, int n) {
        double ox = 20, oy = 24;
        titre(gc, "Plan 2D – Niveau " + n + "  —  " + getNomBatiment(), ox, oy);

        piece(gc, ox+16,  oy+30,  174, 90,  "#e8daef", "Chambre 1",   "14.0 m²", "#6c3483");
        piece(gc, ox+190, oy+30,  200, 90,  "#d6eaf8", "Chambre 2",   "12.0 m²", "#1a5276");
        piece(gc, ox+16,  oy+120, 374, 100, "#d5f5e3", "Séjour open","28.0 m²", "#1e8449");

        gc.setStroke(Color.web("#2980b9")); gc.setLineWidth(2.5);
        gc.setLineDashes(6, 4);
        gc.strokeLine(ox+200, oy+30, ox+320, oy+30);
        gc.setLineDashes(0);

        legende(gc, ox, oy + 240);
    }

    private void piece(GraphicsContext gc, double x, double y, double w, double h,
                       String fill, String label, String surface, String textColor) {
        gc.setFill(Color.web(fill));
        gc.fillRect(x, y, w, h);
        gc.setStroke(Color.web("#2c3e50")); gc.setLineWidth(1.5);
        gc.strokeRect(x, y, w, h);
        gc.setFill(Color.web(textColor));
        gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
        gc.fillText(label,   x + w/2 - mesureTexte(label,  11)/2, y + h/2 - 5);
        gc.setFont(Font.font("Arial", 10));
        gc.fillText(surface, x + w/2 - mesureTexte(surface,10)/2, y + h/2 + 10);
    }

    private void titre(GraphicsContext gc, String t, double x, double y) {
        gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
        gc.setFill(Color.web("#2c3e50"));
        gc.fillText(t, x, y);
    }

    private void legende(GraphicsContext gc, double ox, double y) {
        gc.setFill(Color.web("#2980b9")); gc.fillRect(ox, y, 18, 3);
        gc.setFill(Color.web("#2c3e50")); gc.setFont(Font.font("Arial", 9));
        gc.fillText("— fenêtre", ox + 22, y + 4);
    }

    private double mesureTexte(String t, double size) { return t.length() * size * 0.55; }

    // ------------------------------------------------------------------ //
    //  API publique                                                        //
    // ------------------------------------------------------------------ //

    /** Met a jour la liste d'etages et redessine. */
    public void setEtages(List<String> liste) {
        etages = liste;
        etageBox.setItems(FXCollections.observableArrayList(liste));
        etageBox.getSelectionModel().selectFirst();
        etageActuel = 0;
        dessinerPlan();
    }

    /** Redimensionne le canvas et redessine (appele si la fenetre change de taille). */
    public void redimensionnerCanvas(double w, double h) {
        if (w > 50 && h > 50) {
            canvas.setWidth(w);
            canvas.setHeight(h);
            dessinerPlan();
        }
    }

    protected String getNomBatiment() { return "Bâtiment B001"; }

    protected abstract void construireDemos(VBox conteneur);

    public Region getRoot() { return root; }
    public Canvas  getCanvas() { return canvas; }

    /** Aide : enveloppe un composant de demo dans un bloc avec son nom. */
    protected Node bloc(String titre, Node... composants) {
        Label l = new Label(titre);
        l.setStyle("-fx-font-weight:bold; -fx-text-fill:#335;");
        VBox v = new VBox(6, l);
        for (Node n : composants) v.getChildren().add(n);
        v.setStyle("-fx-padding:8; -fx-background-color:#f7f7fa; -fx-border-color:#ccd; -fx-border-radius:4;");
        return v;
    }
}

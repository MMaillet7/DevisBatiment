package com.example.catalogue.controller;

import com.example.catalogue.model.CatalogueModel;
import com.example.catalogue.model.CategoryType;
import com.example.catalogue.view.*;

/**
 * Controleur principal.
 */
public class MainController {

    private final CatalogueModel model;
    private final MainView       view;

    public MainController(CatalogueModel model, MainView view) {
        this.model = model;
        this.view  = view;
        connecterSousControleurs();
        connecterEvenements();
    }

    private void connecterSousControleurs() {
        new BoutonsController(model,
            (BoutonsView) view.getVue(CategoryType.BOUTONS), view.getBarreEtat());
        new SaisieController(model,
            (SaisieView) view.getVue(CategoryType.SAISIE), view.getBarreEtat());
        new ChoixController(model,
            (ChoixView) view.getVue(CategoryType.CHOIX), view.getBarreEtat());
        new AffichageController(model,
            (AffichageView) view.getVue(CategoryType.AFFICHAGE), view.getBarreEtat());
        new TableauxController(model,
            (TableauxView) view.getVue(CategoryType.TABLEAUX), view.getBarreEtat());
        new MenusDialoguesController(model,
            (MenusDialoguesView) view.getVue(CategoryType.MENUS_DIALOGUES), view.getBarreEtat());
        // CatalogueView et HierarchieView sont purement demonstratives.
    }

    private void connecterEvenements() {
        view.getTabPane().getSelectionModel().selectedItemProperty()
            .addListener((obs, ancien, nouveau) -> {
                if (nouveau != null && nouveau.getUserData() instanceof CategoryType type) {
                    view.getBarreEtat().setText("Onglet courant : " + type.getLibelle());
                }
            });
    }
}

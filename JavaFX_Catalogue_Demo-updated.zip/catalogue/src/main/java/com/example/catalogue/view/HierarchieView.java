package com.example.catalogue.view;

import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.VBox;

/**
 * Onglet Hiérarchie : affiche uniquement l'arborescence Bâtiment > Niveau > Appartement > Pièce.
 */
public class HierarchieView extends CategoryView {

    private TreeView<String> treeView;

    @Override
    protected void construireDemos(VBox conteneur) {
        TreeItem<String> batiment = new TreeItem<>("Bâtiment B001 (Immeuble)");

        TreeItem<String> niv0 = new TreeItem<>("Niveau 0 – RDC");
        TreeItem<String> a01  = new TreeItem<>("Appart A01");
        a01.getChildren().addAll(
            new TreeItem<>("Chambre"), new TreeItem<>("Cuisine"),
            new TreeItem<>("Salon"),   new TreeItem<>("Salle de bain")
        );
        TreeItem<String> a02 = new TreeItem<>("Appart A02");
        a02.getChildren().addAll(new TreeItem<>("Chambre"), new TreeItem<>("Cuisine"));
        niv0.getChildren().addAll(a01, a02);

        TreeItem<String> niv1 = new TreeItem<>("Niveau 1");
        TreeItem<String> a11  = new TreeItem<>("Appart A11");
        a11.getChildren().addAll(
            new TreeItem<>("Chambre 1"), new TreeItem<>("Chambre 2"),
            new TreeItem<>("Cuisine"),   new TreeItem<>("Salle de bain")
        );
        niv1.getChildren().add(a11);

        TreeItem<String> niv2 = new TreeItem<>("Niveau 2");
        TreeItem<String> a21  = new TreeItem<>("Appart A21");
        a21.getChildren().addAll(new TreeItem<>("Chambre"), new TreeItem<>("Cuisine"), new TreeItem<>("Salon"));
        niv2.getChildren().add(a21);

        batiment.getChildren().addAll(niv0, niv1, niv2);
        batiment.setExpanded(true);
        niv0.setExpanded(true);
        a01.setExpanded(true);

        treeView = new TreeView<>(batiment);
        treeView.setPrefHeight(350);

        conteneur.getChildren().add(
            bloc("TreeView  —  Hiérarchie Bâtiment > Niveau > Appartement > Pièce", treeView)
        );
    }

    public TreeView<String> getTreeView() { return treeView; }
}

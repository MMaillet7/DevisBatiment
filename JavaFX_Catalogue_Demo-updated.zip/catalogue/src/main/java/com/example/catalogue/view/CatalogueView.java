package com.example.catalogue.view;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

/**
 * Onglet Catalogue : affiche uniquement le tableau des revêtements.
 */
public class CatalogueView extends CategoryView {

    public static class Revetement {
        private final StringProperty id      = new SimpleStringProperty();
        private final StringProperty type    = new SimpleStringProperty();
        private final StringProperty support = new SimpleStringProperty();
        private final DoubleProperty prix    = new SimpleDoubleProperty();

        public Revetement(String id, String type, String support, double prix) {
            this.id.set(id); this.type.set(type);
            this.support.set(support); this.prix.set(prix);
        }

        public String getId()           { return id.get(); }
        public String getType()         { return type.get(); }
        public String getSupport()      { return support.get(); }
        public double getPrixUnitaire() { return prix.get(); }
        public StringProperty idProperty()      { return id; }
        public StringProperty typeProperty()    { return type; }
        public StringProperty supportProperty() { return support; }
        public DoubleProperty prixProperty()    { return prix; }
    }

    private TableView<Revetement> tableView;

    @Override
    @SuppressWarnings("unchecked")
    protected void construireDemos(VBox conteneur) {
        tableView = new TableView<>();

        TableColumn<Revetement, String> colId      = new TableColumn<>("ID");
        TableColumn<Revetement, String> colType    = new TableColumn<>("Type");
        TableColumn<Revetement, String> colSupport = new TableColumn<>("Support");
        TableColumn<Revetement, Double> colPrix    = new TableColumn<>("Prix (€/m²)");

        colId.setCellValueFactory(new PropertyValueFactory<>("id"));           colId.setPrefWidth(80);
        colType.setCellValueFactory(new PropertyValueFactory<>("type"));       colType.setPrefWidth(180);
        colSupport.setCellValueFactory(new PropertyValueFactory<>("support")); colSupport.setPrefWidth(160);
        colPrix.setCellValueFactory(new PropertyValueFactory<>("prixUnitaire")); colPrix.setPrefWidth(110);

        ObservableList<Revetement> catalogue = FXCollections.observableArrayList(
            new Revetement("REV001", "Peinture",         "Mur / Plafond",  8.50),
            new Revetement("REV002", "Carrelage",        "Sol / Mur",     35.00),
            new Revetement("REV003", "Parquet",          "Sol",           45.00),
            new Revetement("REV004", "Papier peint",     "Mur",           12.00),
            new Revetement("REV005", "Bardage",          "Facade",        60.00),
            new Revetement("REV006", "Isolant projeté",  "Facade",        50.00),
            new Revetement("REV007", "Isolant rapporté", "Facade",        55.00)
        );
        tableView.setItems(catalogue);
        tableView.getColumns().addAll(colId, colType, colSupport, colPrix);
        tableView.setPrefHeight(280);

        conteneur.getChildren().add(
            bloc("TableView  —  Catalogue de revêtements", tableView)
        );
    }

    public TableView<Revetement> getTableView() { return tableView; }
}

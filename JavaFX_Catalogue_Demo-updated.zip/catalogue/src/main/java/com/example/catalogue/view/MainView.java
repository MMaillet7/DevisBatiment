package com.example.catalogue.view;

import com.example.catalogue.model.CategoryType;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Region;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Vue principale : BorderPane contenant un TabPane (un onglet par categorie)
 * et une barre d'etat en bas.
 */
public class MainView {

    private final BorderPane root    = new BorderPane();
    private final TabPane    tabPane = new TabPane();
    private final Label      barreEtat = new Label("Prêt. Sélectionnez un onglet pour explorer les composants.");
    private final Map<CategoryType, CategoryView> vues = new EnumMap<>(CategoryType.class);

    private String typeBatiment = "Maison individuelle";

    public MainView() {
        construire();
    }

    private void construire() {
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        for (CategoryType type : CategoryType.values()) {
            CategoryView vue = creerVue(type);
            vues.put(type, vue);
            Tab onglet = new Tab(type.getLibelle(), vue.getRoot());
            onglet.setUserData(type);
            tabPane.getTabs().add(onglet);
        }

        barreEtat.setStyle("-fx-padding:6 10; -fx-background-color:#eef; -fx-border-color:#ccd;");
        barreEtat.setMaxWidth(Double.MAX_VALUE);

        root.setCenter(tabPane);
        root.setBottom(barreEtat);
    }

    private CategoryView creerVue(CategoryType type) {
        return switch (type) {
            case BOUTONS         -> new BoutonsView();
            case SAISIE          -> new SaisieView();
            case CHOIX           -> new ChoixView();
            case AFFICHAGE       -> new AffichageView();
            case CONTENEURS      -> new ConteneursView();
            case TABLEAUX        -> new TableauxView();
            case MENUS_DIALOGUES -> new MenusDialoguesView();
            case CATALOGUE       -> new CatalogueView();
            case HIERARCHIE      -> new HierarchieView();
        };
    }

    /**
     * Met à jour les listes d'étages de tous les onglets selon le type de bâtiment choisi.
     */
    public void appliquerTypeBatiment(String type) {
        this.typeBatiment = type;
        List<String> etages = type.equals("Immeuble")
            ? List.of("Niveau 0 – RDC", "Niveau 1", "Niveau 2")
            : List.of("Niveau 0 – RDC");

        vues.values().forEach(vue -> vue.setEtages(etages));
        barreEtat.setText("Type de bâtiment : " + type + " — " + etages.size() + " niveau(x)");
    }

    public Region getRoot()      { return root; }
    public TabPane getTabPane()  { return tabPane; }
    public Label getBarreEtat()  { return barreEtat; }
    public CategoryView getVue(CategoryType type) { return vues.get(type); }
    public Map<CategoryType, CategoryView> getVues() { return vues; }
    public String getTypeBatiment() { return typeBatiment; }
}

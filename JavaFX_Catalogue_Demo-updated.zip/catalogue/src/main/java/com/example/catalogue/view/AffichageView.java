package com.example.catalogue.view;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * Demonstrations des composants d'affichage.
 * Le plan 2D est desormais dans le panneau droit commun (CategoryView).
 */
public class AffichageView extends CategoryView {

    private Label             labelDevis;
    private ProgressBar       progressBar;
    private ProgressIndicator progressIndicator;

    @Override
    protected void construireDemos(VBox conteneur) {
        labelDevis        = new Label("Devis total : 48 750 €");
        progressBar       = new ProgressBar(0.0);
        progressIndicator = new ProgressIndicator();

        labelDevis.setStyle("-fx-font-size:18; -fx-font-weight:bold; -fx-text-fill:#1a5276;");
        Tooltip.install(labelDevis, new Tooltip("Résultat du calcul de devis (Étape 2)"));

        progressIndicator.setProgress(ProgressIndicator.INDETERMINATE_PROGRESS);
        progressIndicator.setPrefSize(40, 40);

        HBox progress = new HBox(20, progressBar, progressIndicator);
        progress.setAlignment(Pos.CENTER_LEFT);

        conteneur.getChildren().addAll(
            bloc("Label  —  Résultat du devis", labelDevis),
            bloc("ProgressBar / ProgressIndicator  —  Calcul / chargement", progress)
        );
    }

    public Label             getLabelDevis()        { return labelDevis; }
    public ProgressBar       getProgressBar()       { return progressBar; }
    public ProgressIndicator getProgressIndicator() { return progressIndicator; }
}

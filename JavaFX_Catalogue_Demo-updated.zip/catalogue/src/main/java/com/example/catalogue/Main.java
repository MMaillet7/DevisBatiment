package com.example.catalogue;

import com.example.catalogue.controller.MainController;
import com.example.catalogue.model.CatalogueModel;
import com.example.catalogue.view.MainView;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.util.Optional;

/**
 * Point d'entrée de l'application JavaFX.
 * Affiche d'abord une fenêtre de choix du type de bâtiment,
 * puis ouvre la fenêtre principale en plein écran.
 */
public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {

        // --- Fenêtre de démarrage : choix du type de bâtiment ---
        Optional<String> choix = afficherDialogueChoixBatiment(primaryStage);
        if (choix.isEmpty()) {
            // L'utilisateur a fermé la fenêtre sans choisir
            return;
        }
        String typeBatiment = choix.get();

        // --- Fenêtre principale ---
        CatalogueModel model = new CatalogueModel();
        model.setTypeBatiment(typeBatiment);

        MainView view = new MainView();
        new MainController(model, view);

        // Appliquer le type de bâtiment (étages, plan)
        view.appliquerTypeBatiment(typeBatiment);

        Scene scene = new Scene(view.getRoot());
        primaryStage.setTitle("Catalogue JavaFX – " + typeBatiment);
        primaryStage.setScene(scene);
        primaryStage.setMaximized(true);   // plein écran au démarrage
        primaryStage.show();
    }

    /**
     * Affiche une fenêtre modale demandant le type de bâtiment.
     * Retourne Optional.empty() si l'utilisateur ferme sans valider.
     */
    private Optional<String> afficherDialogueChoixBatiment(Stage owner) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initStyle(StageStyle.UTILITY);
        dialog.setTitle("Nouveau bâtiment");
        dialog.setResizable(false);

        Label titre = new Label("Type de bâtiment");
        titre.setFont(Font.font("System", FontWeight.BOLD, 16));

        Label sousTitre = new Label("Choisissez le type avant d'ouvrir le catalogue :");
        sousTitre.setStyle("-fx-text-fill: #555;");

        ToggleGroup groupe = new ToggleGroup();
        RadioButton rbMaison   = new RadioButton("Maison individuelle");
        RadioButton rbImmeuble = new RadioButton("Immeuble");
        rbMaison.setToggleGroup(groupe);
        rbImmeuble.setToggleGroup(groupe);
        rbMaison.setSelected(true);
        rbMaison.setStyle("-fx-font-size:13;");
        rbImmeuble.setStyle("-fx-font-size:13;");

        Button btnOk = new Button("Ouvrir le catalogue");
        btnOk.setDefaultButton(true);
        btnOk.setStyle("-fx-font-size:13; -fx-padding:8 20;");

        final String[] resultat = {null};

        btnOk.setOnAction(e -> {
            resultat[0] = rbImmeuble.isSelected() ? "Immeuble" : "Maison individuelle";
            dialog.close();
        });

        dialog.setOnCloseRequest(e -> resultat[0] = null);

        VBox layout = new VBox(14, titre, sousTitre, rbMaison, rbImmeuble, btnOk);
        layout.setPadding(new Insets(28));
        layout.setAlignment(Pos.CENTER_LEFT);
        layout.setMinWidth(320);
        btnOk.setMaxWidth(Double.MAX_VALUE);

        dialog.setScene(new Scene(layout));
        dialog.showAndWait();

        return resultat[0] == null ? Optional.empty() : Optional.of(resultat[0]);
    }

    public static void main(String[] args) {
        launch(args);
    }
}

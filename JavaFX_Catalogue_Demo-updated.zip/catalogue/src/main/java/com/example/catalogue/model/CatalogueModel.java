package com.example.catalogue.model;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Modele du catalogue : centralise les donnees descriptives utilisees
 * par les vues (texte d'aide, exemples de code).
 */
public class CatalogueModel {

    private final Map<CategoryType, List<ComponentInfo>> donnees = new EnumMap<>(CategoryType.class);
    private String typeBatiment = "Maison individuelle";
    private String journal = "";

    public CatalogueModel() {
        chargerDonnees();
    }

    private void chargerDonnees() {
        donnees.put(CategoryType.BOUTONS, List.of(
            new ComponentInfo("Button",
                "Declenche une action : calculer le devis, valider un formulaire de saisie, enregistrer.",
                "Button b = new Button(\"Calculer le devis\");\nb.setOnAction(e -> calculerDevis());"),
            new ComponentInfo("ToggleButton",
                "Active/desactive une option : ex. afficher/masquer les murs de facade.",
                "ToggleButton t = new ToggleButton(\"Afficher facades\");\nt.setOnAction(e -> toggleFacades(t.isSelected()));"),
            new ComponentInfo("RadioButton",
                "Choix exclusif : type de batiment (Maison ou Immeuble).",
                "ToggleGroup g = new ToggleGroup();\nRadioButton r1 = new RadioButton(\"Maison\");\nRadioButton r2 = new RadioButton(\"Immeuble\");\nr1.setToggleGroup(g);\nr2.setToggleGroup(g);"),
            new ComponentInfo("CheckBox",
                "Option independante : inclure l'isolation facade, afficher le plafond, etc.",
                "CheckBox c = new CheckBox(\"Inclure isolation facade\");\nc.setSelected(true);"),
            new ComponentInfo("Hyperlink",
                "Lien vers une documentation, un catalogue en ligne ou une ressource externe.",
                "Hyperlink h = new Hyperlink(\"Voir catalogue revetements\");\nh.setOnAction(e -> ouvrirCatalogue());")
        ));

        donnees.put(CategoryType.SAISIE, List.of(
            new ComponentInfo("TextField",
                "Saisir un identifiant ou une valeur numerique : idBatiment, idNiveau, idAppart, largeur mur.",
                "TextField tf = new TextField();\ntf.setPromptText(\"ID Batiment (ex: B001)\");"),
            new ComponentInfo("PasswordField",
                "Proteger l'acces a l'application (authentification optionnelle).",
                "PasswordField pf = new PasswordField();\npf.setPromptText(\"Mot de passe\");"),
            new ComponentInfo("TextArea",
                "Saisir une description detaillee du batiment ou des notes sur le devis.",
                "TextArea ta = new TextArea();\nta.setPromptText(\"Notes sur le devis...\");\nta.setWrapText(true);")
        ));

        donnees.put(CategoryType.CHOIX, List.of(
            new ComponentInfo("ChoiceBox",
                "Choisir le type de batiment : Maison individuelle ou Immeuble.",
                "ChoiceBox<String> cb = new ChoiceBox<>();\ncb.getItems().addAll(\"Maison\", \"Immeuble\");\ncb.getSelectionModel().selectFirst();"),
            new ComponentInfo("ComboBox",
                "Selectionner un type de revetement dans le catalogue.",
                "ComboBox<String> cb = new ComboBox<>();\ncb.getItems().addAll(\"Peinture\", \"Carrelage\", \"Parquet\");\ncb.setEditable(true);"),
            new ComponentInfo("DatePicker",
                "Choisir la date d'etablissement du devis.",
                "DatePicker dp = new DatePicker(LocalDate.now());"),
            new ComponentInfo("ColorPicker",
                "Choisir la couleur d'une peinture ou d'un revetement.",
                "ColorPicker cp = new ColorPicker(Color.WHITE);"),
            new ComponentInfo("Slider",
                "Ajuster la hauteur sous plafond d'un niveau (ex: 2.0 a 4.0 m).",
                "Slider s = new Slider(2.0, 4.0, 2.5);\ns.setMajorTickUnit(0.5);"),
            new ComponentInfo("Spinner",
                "Saisir le nombre de niveaux ou d'appartements.",
                "Spinner<Integer> sp = new Spinner<>(1, 20, 1);\nsp.setEditable(true);")
        ));

        donnees.put(CategoryType.AFFICHAGE, List.of(
            new ComponentInfo("Label",
                "Afficher un resultat : surface totale, prix d'un revetement, devis total (euros).",
                "Label l = new Label(\"Devis total : 12 500 €\");\nl.setStyle(\"-fx-font-size:16; -fx-font-weight:bold;\");"),
            new ComponentInfo("ProgressBar",
                "Indiquer la progression d'un calcul.",
                "ProgressBar pb = new ProgressBar();\npb.setProgress(0.7);"),
            new ComponentInfo("ProgressIndicator",
                "Indicateur circulaire de progression.",
                "ProgressIndicator pi = new ProgressIndicator();\npi.setProgress(ProgressIndicator.INDETERMINATE_PROGRESS);"),
            new ComponentInfo("Canvas",
                "Dessiner le plan 2D des pieces d'un niveau.",
                "Canvas canvas = new Canvas(400, 300);\nGraphicsContext gc = canvas.getGraphicsContext2D();\ngc.strokeRect(x, y, largeur, hauteur);")
        ));

        donnees.put(CategoryType.CONTENEURS, List.of(
            new ComponentInfo("VBox", "Organisation verticale.", "VBox v = new VBox(10, a, b, c);"),
            new ComponentInfo("HBox", "Organisation horizontale.", "HBox h = new HBox(10, a, b, c);"),
            new ComponentInfo("BorderPane", "Structure 5 zones.", "BorderPane bp = new BorderPane();\nbp.setCenter(plan);"),
            new ComponentInfo("GridPane", "Grille label+champ.", "GridPane g = new GridPane();\ng.add(label, 0, 0);\ng.add(field, 1, 0);"),
            new ComponentInfo("StackPane", "Superposition de calques.", "StackPane sp = new StackPane(canvas, annotations);")
        ));

        donnees.put(CategoryType.TABLEAUX, List.of(
            new ComponentInfo("ListView", "Liste des usages de pieces.", "ListView<String> lv = new ListView<>();\nlv.getItems().addAll(\"Chambre\", \"Cuisine\");"),
            new ComponentInfo("TableView", "Catalogue de revetements.", "TableView<Revetement> table = new TableView<>();"),
            new ComponentInfo("TreeView", "Hierarchie Batiment > Niveau > Appart > Piece.", "TreeItem<String> bat = new TreeItem<>(\"B001\");")
        ));

        donnees.put(CategoryType.MENUS_DIALOGUES, List.of(
            new ComponentInfo("MenuBar", "Barre de menus Fichier/Devis/Aide.", "MenuBar mb = new MenuBar();"),
            new ComponentInfo("ContextMenu", "Menu clic droit sur une piece.", "ContextMenu cm = new ContextMenu();"),
            new ComponentInfo("Alert", "Afficher le devis total ou une erreur.", "Alert a = new Alert(AlertType.INFORMATION);"),
            new ComponentInfo("TextInputDialog", "Demander l'ID du batiment.", "TextInputDialog d = new TextInputDialog(\"B001\");"),
            new ComponentInfo("FileChooser", "Ouvrir/sauvegarder un fichier.", "FileChooser fc = new FileChooser();")
        ));

        donnees.put(CategoryType.CATALOGUE, List.of());
        donnees.put(CategoryType.HIERARCHIE, List.of());
    }

    public List<ComponentInfo> getComposants(CategoryType type) {
        return donnees.getOrDefault(type, List.of());
    }

    public String getTypeBatiment() { return typeBatiment; }
    public void setTypeBatiment(String type) { this.typeBatiment = type; }

    public void ajouterAuJournal(String message) { journal += message + "\n"; }
    public String getJournal() { return journal; }
    public void viderJournal()  { journal = ""; }
}
